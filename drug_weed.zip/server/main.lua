RegisterServerEvent('drug:use')
AddEventHandler('drug:use', function()
    print('Server registered drug use')
end)