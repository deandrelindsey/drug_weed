Config = {
    DrugName = 'drug_weed',
    Enabled = true
}