RegisterCommand('usedrug', function()
    print('Drug used')
end, false)