Locales = Locales or {}
Locales['en'] = {
    ['use'] = 'Use Drug'
}