fx_version 'cerulean'
game 'gta5'

description 'drug_weed resource'
version '1.0.0'

shared_script 'config.lua'
shared_script 'locales/en.lua'
client_script 'client/main.lua'
server_script 'server/main.lua'
